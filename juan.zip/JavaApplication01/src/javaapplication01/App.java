import java.util.ArrayList;
import java.util.Scanner;


public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BaseDeDatos bd = new BaseDeDatos();

        // Agregar un propietario
        Propietario propietario1 = new Propietario();
        propietario1.setNombre("Juan");
        propietario1.setDireccion("Calle 123");
        propietario1.setTelefono("555-1234");
        bd.agregarPropietario(propietario1);

        // Agregar un inquilino relacionado con un propietario existente
        Inquilino inquilino1 = new Inquilino();
        inquilino1.setNombre("Pedro");
        inquilino1.setDireccion("Calle 456");
        inquilino1.setTelefono("555-5678");
        inquilino1.setPropietario(propietario1);
        bd.agregarInquilino(inquilino1);

        // Buscar un propietario por nombre
        // Buscar un propietario por nombre
        System.out.println("Ingrese el nombre del propietario a buscar:");
        String nombrePropietario = sc.nextLine();
        Propietario propietarioEncontrado = bd.buscarPropietario(nombrePropietario);

        if (propietarioEncontrado != null) {
            System.out.println("Nombre: " + propietarioEncontrado.getNombre());
            System.out.println("Dirección: " + propietarioEncontrado.getDireccion());
            System.out.println("Teléfono: " + propietarioEncontrado.getTelefono());

            // Mostrar los inquilinos relacionados con el propietario encontrado
            ArrayList<Inquilino> inquilinosPropietario = new ArrayList<>();
            for (Inquilino inquilino : bd.getInquilinos()) {
                if (inquilino.getPropietario().equals(propietarioEncontrado)) {
                    inquilinosPropietario.add(inquilino);

                }

            }

            System.out.println("Inquilinos relacionados:");
            for (Inquilino inquilino : inquilinosPropietario) {
                System.out.println("- " + inquilino.getNombre());
            }

        } else {
            System.out.println("Propietario no encontrado.");
        }

    }
}
