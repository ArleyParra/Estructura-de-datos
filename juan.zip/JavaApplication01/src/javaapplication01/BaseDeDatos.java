

import java.util.ArrayList;

public class BaseDeDatos {
    private ArrayList<Propietario> propietarios;
    private ArrayList<Inquilino> inquilinos;

    public BaseDeDatos() {
        propietarios = new ArrayList<>();
        inquilinos = new ArrayList<>();
    }

    public void agregarPropietario(Propietario propietario) {
        propietarios.add(propietario);
    }

    public void eliminarPropietario(Propietario propietario) {
        propietarios.remove(propietario);
    }

    public Propietario buscarPropietario(String nombre) {
        for (Propietario propietario : propietarios) {
            if (propietario.getNombre().equals(nombre)) {
                return propietario;
            }
        }
        return null;
    }

    public void agregarInquilino(Inquilino inquilino) {
        inquilinos.add(inquilino);
    }

    public void eliminarInquilino(Inquilino inquilino) {
        inquilinos.remove(inquilino);
    }

    public Inquilino buscarInquilino(String nombre) {
        for (Inquilino inquilino : inquilinos) {
            if (inquilino.getNombre().equals(nombre)) {
                return inquilino;
            }
        }
        return null;
    }

    
}
