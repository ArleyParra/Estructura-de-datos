package com.example.calculadora2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView tvResultado;
    EditText etNum1 , etNum2;
    Button btnSumar , btnRestar , btnMultiplicar , btnDividir;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResultado = findViewById(R.id.tv_Num_resultado);
        etNum1 = findViewById(R.id.tv_Num_1);
        etNum2 = findViewById(R.id.tv_Num_2);
        btnSumar = findViewById(R.id.btn_Sumar);
        btnRestar = findViewById(R.id.btn_Restar);
        btnMultiplicar = findViewById(R.id.btn_Multiplicar);
        btnDividir = findViewById(R.id.btn_Dividir);
    }

    public void clickSumar(View view){
        String textEtNum1 = etNum1.getText().toString();
        Double num1 = Double.parseDouble(textEtNum1);

        String textEtNum2 = etNum2.getText().toString();
        Double num2 = Double.parseDouble(textEtNum2);

        Double resultado = num1+num2;
        tvResultado.setText(resultado.toString());


        Toast.makeText(this, "click sumar", Toast.LENGTH_SHORT).show();
    }
}